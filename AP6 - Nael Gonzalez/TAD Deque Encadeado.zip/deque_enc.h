#ifndef _DEQUE_ENC_H_
#define _DEQUE_ENC_H_

#define TAM_MAX_NOME 40
#define TAM_MAX_EMAIL 25

typedef struct{
   int matricula;
   char nome[TAM_MAX_NOME];
   char email[TAM_MAX_EMAIL];
} Aluno;

typedef Aluno Info;

typedef struct nodoLEnc2{
   Info info;
   struct nodoLEnc2 *ant;
   struct nodoLEnc2 *prox;
} NodoLEnc2;

typedef struct dequeEnc{
   struct nodoLEnc2 *ini;
   struct nodoLEnc2 *fim;
} DequeEnc;

// Funcao que cria um deque
DequeEnc* criaDeque();

// Funcao que destroi um deque
void destroiDeque(DequeEnc *deque);

// Funcao que insere um elemento no inicio do deque
void insereInicioDeque(DequeEnc *deque, Info info);

// Funcao que insere um elemento no fim do deque
void insereFimDeque(DequeEnc *deque, Info info);

// Funcao que remove um elemento do inicio do deque
Info removeInicioDeque(DequeEnc *deque);

// Funcao que remove um elemento do fim do deque
Info removeFimDeque(DequeEnc *deque);

// Funcao que determina se um deque eh vazio
int vazioDeque(DequeEnc* deque);


#endif
